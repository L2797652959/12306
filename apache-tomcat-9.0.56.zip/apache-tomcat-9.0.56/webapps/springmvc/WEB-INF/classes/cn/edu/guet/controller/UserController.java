package cn.edu.guet.controller;

import cn.edu.guet.bean.Permission;
import cn.edu.guet.bean.Result;
import cn.edu.guet.bean.User;
import cn.edu.guet.mvc.annotation.Controller;
import cn.edu.guet.mvc.annotation.RequestMapping;
import cn.edu.guet.service.UserService;
import java.sql.SQLException;
import java.util.List;

/**
 * @Author liwei
 * @Date 2022/12/27 10:49
 * @Version 1.0
 */
@Controller
public class UserController {

    private UserService userService;

    // 实现自动注入，也是官方Spring框架的核心功能（DI：依赖注入），低耦合
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * 只要1000说明成功
     *
     * @param username
     * @param password
     * @return
     */
    @RequestMapping("/login")
    public Result login(String username, String password) {
        try {
            User user = userService.login(username, password);
            if (user != null) {
                return new Result(1000, user);
            } else {
                return new Result(1001, null);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping("/getPermissionByUserId")
    public List<Permission> getPermissionByUserId(int userId) {
        List<Permission> permissionList = null;
        try {
            permissionList = userService.getPermissionByUserId(userId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("用户的菜单：" + permissionList);
        return permissionList;// 返回的是JSON格式数据
    }
}