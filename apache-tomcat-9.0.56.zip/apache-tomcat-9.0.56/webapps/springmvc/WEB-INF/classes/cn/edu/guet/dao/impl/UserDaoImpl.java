package cn.edu.guet.dao.impl;

import cn.edu.guet.bean.Permission;
import cn.edu.guet.bean.User;
import cn.edu.guet.dao.UserDao;
import cn.edu.guet.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author liwei
 * @Date 2022/12/27 11:15
 * @Version 1.0
 */
public class UserDaoImpl implements UserDao {

    @Override
    public User login(String username, String password) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        conn = DBConnection.getConn();
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, username);
        pstmt.setString(2, password);
        rs = pstmt.executeQuery();
        if (rs.next()) {
            User user = new User();
            user.setUserId(rs.getInt("user_id"));
            user.setUsername(rs.getString("username"));
            return user;
        }
        return null;
    }

    @Override
    public List<Permission> getPermissionByUserId(int userId) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "SELECT p.*\n" +
                "FROM user_role ur,role_permission rp,permissions p\n" +
                "WHERE ur.role_id=rp.role_id\n" +
                "AND rp.per_id=p.per_id AND ur.user_id=?";
        conn = DBConnection.getConn();
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, userId);
        rs = pstmt.executeQuery();
        List<Permission> permissionList = new ArrayList<>();
        while (rs.next()) {
            Permission permission = new Permission();
            permission.setPerId(rs.getInt("PER_ID"));
            permission.setName(rs.getString("NAME"));
            permission.setUrl(rs.getString("URL"));
            permission.setTarget(rs.getString("TARGET"));
            permission.setIcon(rs.getString("ICON"));
            permission.setIsParent(rs.getString("ISPARENT"));
            permissionList.add(permission);
        }
        return permissionList;
    }
}