package cn.edu.guet.service;

import cn.edu.guet.bean.Permission;
import cn.edu.guet.bean.User;

import java.sql.SQLException;
import java.util.List;

/**
 * @Author liwei
 * @Date 2022/12/27 11:20
 * @Version 1.0
 */
public interface UserService {
    User login(String username,String password) throws SQLException;
    List<Permission> getPermissionByUserId(int userId) throws SQLException;
}
