package cn.edu.guet.bean;

import java.util.List;

/**
 * @Author liwei
 * @Date 2022/12/29 10:56
 * @Version 1.0
 */
public class Role {

    private int roleId;
    private String roleName;
    private List<Permission> permissionList;

    public Role() {
    }

    public Role(int roleId, String roleName, List<Permission> permissionList) {
        this.roleId = roleId;
        this.roleName = roleName;
        this.permissionList = permissionList;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public List<Permission> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List<Permission> permissionList) {
        this.permissionList = permissionList;
    }
}
