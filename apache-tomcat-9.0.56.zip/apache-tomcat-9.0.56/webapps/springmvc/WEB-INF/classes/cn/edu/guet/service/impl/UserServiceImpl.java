package cn.edu.guet.service.impl;

import cn.edu.guet.bean.Permission;
import cn.edu.guet.bean.User;
import cn.edu.guet.dao.UserDao;
import cn.edu.guet.dao.impl.UserDaoImpl;
import cn.edu.guet.service.UserService;

import java.sql.SQLException;
import java.util.List;

/**
 * @Author liwei
 * @Date 2022/12/27 11:20
 * @Version 1.0
 */
public class UserServiceImpl implements UserService {

    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public User login(String username, String password) throws SQLException {
        return userDao.login(username, password);
    }

    @Override
    public List<Permission> getPermissionByUserId(int userId) throws SQLException {
        return userDao.getPermissionByUserId(userId);
    }

}
