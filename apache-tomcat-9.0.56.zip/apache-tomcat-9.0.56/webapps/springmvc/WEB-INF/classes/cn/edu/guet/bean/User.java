package cn.edu.guet.bean;


import java.util.List;

public class User {

    private int userId;
    private String username;
    private List<Role> roleList;

    public User() {
    }

    public User(int userId, String username, List<Role> roleList) {
        this.userId = userId;
        this.username = username;
        this.roleList = roleList;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<Role> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<Role> roleList) {
        this.roleList = roleList;
    }
}
